#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/local/lib"
XML2_LIBS="-lxml2 -L/usr/local/lib -lz  -L/usr/local/lib -liconv  "
XML2_INCLUDEDIR="-I/usr/local/include/libxml2 -I/usr/local/include"
MODULE_VERSION="xml2-2.9.3"

